# -*- coding: utf-8 -*-
import os
import math
import traceback

from qgis.PyQt.QtWidgets import (QAction, QDialog, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QLineEdit, QFileDialog, QComboBox, QTabWidget,
    QWidget, QFormLayout, QMessageBox, QCheckBox)
from qgis.core import (QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem,
    QgsGeometry, QgsPointXY, QgsFeature, QgsField, QgsWkbTypes,
    QgsVectorFileWriter, QgsProcessingFeedback, QgsDistanceArea,
    QgsCoordinateTransform)
from qgis.PyQt.QtCore import QVariant
import processing


def selector_archivo(parent, line, file_filter, save=False):
    if save:
        path, _ = QFileDialog.getSaveFileName(parent, 'Archivo de salida', line.text(), file_filter)
        if path and not os.path.splitext(path)[1]:
            path += '.gpkg'
    else:
        path, _ = QFileDialog.getOpenFileName(parent, 'Seleccionar archivo', line.text(), file_filter)
    if path:
        line.setText(path)


def path_control(parent, filter_text, save=False):
    edit = QLineEdit()
    row = QWidget()
    layout = QHBoxLayout(row)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.addWidget(edit)
    button = QPushButton('Examinar…')
    button.clicked.connect(lambda: selector_archivo(parent, edit, filter_text, save))
    layout.addWidget(button)
    return row, edit


class GeoToolsDialog(QDialog):
    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.setWindowTitle('GeoTools GT | Caja de geoprocesos')
        self.resize(720, 440)
        root = QVBoxLayout(self)
        tabs = QTabWidget()
        root.addWidget(tabs)
        self.excel_tab = QWidget()
        self.extract_tab = QWidget()
        self.reproj_tab = QWidget()
        tabs.addTab(self.excel_tab, 'Excel → geometrías')
        tabs.addTab(self.extract_tab, 'Polígono → vértices')
        tabs.addTab(self.reproj_tab, 'Reproyectar capa')
        self.setup_excel()
        self.setup_extract()
        self.setup_reproject()
        bottom = QHBoxLayout()
        self.status = QLabel('Listo. Las salidas se guardan como GeoPackage (*.gpkg).')
        self.status.setWordWrap(True)
        bottom.addWidget(self.status, 1)
        refresh = QPushButton('Actualizar capas')
        refresh.clicked.connect(self.refresh_layers)
        bottom.addWidget(refresh)
        root.addLayout(bottom)
        self.refresh_layers()

    def setup_excel(self):
        layout = QVBoxLayout(self.excel_tab)
        form = QFormLayout()
        field, self.xlsx = path_control(self, 'Excel (*.xlsx *.xls)')
        form.addRow('Archivo Excel:', field)
        self.sheet = QComboBox()
        form.addRow('Hoja:', self.sheet)
        self.xlsx.textChanged.connect(self.load_sheets)
        self.sheet.currentIndexChanged.connect(self.load_columns)
        self.xcol = QComboBox()
        self.ycol = QComboBox()
        form.addRow('Columna X / Este:', self.xcol)
        form.addRow('Columna Y / Norte:', self.ycol)
        self.crs_excel = QLineEdit('EPSG:4326')
        form.addRow('SRC de entrada (EPSG):', self.crs_excel)
        self.order = QComboBox()
        form.addRow('Orden de vértices (opcional):', self.order)
        field, self.out_excel = path_control(self, 'GeoPackage (*.gpkg)', True)
        form.addRow('Nombre base de salida (.gpkg):', field)
        layout.addLayout(form)
        note = QLabel('Se generan DOS archivos (_puntos y _poligono). Se requiere al menos 3 vértices distintos; si existe ORDEN, selecciónalo. '
                      'El SRC debe corresponder a las coordenadas originales (no al SRC del proyecto).')
        note.setWordWrap(True)
        layout.addWidget(note)
        run = QPushButton('Generar puntos y polígono')
        run.clicked.connect(self.run_excel)
        layout.addWidget(run)

    def setup_extract(self):
        layout = QVBoxLayout(self.extract_tab)
        form = QFormLayout()
        self.polygons = QComboBox()
        form.addRow('Capa de polígonos:', self.polygons)
        field, self.out_extract = path_control(self, 'GeoPackage (*.gpkg)', True)
        form.addRow('Archivo de puntos de salida:', field)
        layout.addLayout(form)
        note = QLabel('Solo se necesita la capa de polígonos. Se genera una nueva capa de puntos con '
                      'un punto por vértice, su posición X/Y en el SRC original y coordenadas '
                      'geográficas WGS84. Se incluyen vértices de anillos interiores.')
        note.setWordWrap(True)
        layout.addWidget(note)
        run = QPushButton('Generar puntos desde el polígono')
        run.clicked.connect(self.run_extract)
        layout.addWidget(run)

    def setup_reproject(self):
        layout = QVBoxLayout(self.reproj_tab)
        form = QFormLayout()
        self.vector = QComboBox()
        form.addRow('Capa vectorial:', self.vector)
        self.target_crs = QLineEdit('EPSG:4326')
        form.addRow('SRC de destino (EPSG):', self.target_crs)
        field, self.out_reproj = path_control(self, 'GeoPackage (*.gpkg)', True)
        form.addRow('Archivo de salida:', field)
        layout.addLayout(form)
        note = QLabel('Reproyecta realmente las coordenadas; no se limita a asignar un SRC. '
                      'La capa de origen debe tener un SRC correctamente definido.')
        note.setWordWrap(True)
        layout.addWidget(note)
        run = QPushButton('Reproyectar')
        run.clicked.connect(self.run_reproject)
        layout.addWidget(run)

    def refresh_layers(self):
        layers = [x for x in QgsProject.instance().mapLayers().values()
                  if isinstance(x, QgsVectorLayer) and x.isValid()]
        for combo, selected in ((self.polygons, QgsWkbTypes.PolygonGeometry),
                                (self.vector, None)):
            previous = combo.currentData()
            combo.clear()
            for layer in sorted(layers, key=lambda l: l.name().lower()):
                if selected is None or layer.geometryType() == selected:
                    combo.addItem(layer.name(), layer.id())
            idx = combo.findData(previous)
            if idx >= 0:
                combo.setCurrentIndex(idx)

    def get_layer(self, combo):
        layer = QgsProject.instance().mapLayer(combo.currentData())
        if not layer or not layer.isValid():
            raise ValueError('Selecciona una capa válida. Pulsa Actualizar capas si es necesario.')
        return layer

    def get_crs(self, edit):
        authid = edit.text().strip().upper()
        crs = QgsCoordinateReferenceSystem(authid)
        if not crs.isValid():
            raise ValueError('SRC no válido: {}. Usa un código como EPSG:4326.'.format(authid))
        return crs

    def get_output(self, edit):
        path = os.path.abspath(edit.text().strip()) if edit.text().strip() else ''
        if not path:
            raise ValueError('Selecciona un archivo de salida.')
        if not path.lower().endswith('.gpkg'):
            raise ValueError('La salida debe ser un archivo .gpkg.')
        if os.path.exists(path):
            raise ValueError('El archivo de salida ya existe. Selecciona otro nombre para evitar sobrescribirlo.')
        if not os.path.isdir(os.path.dirname(path)):
            raise ValueError('La carpeta de salida no existe.')
        return path

    def load_sheets(self):
        self.sheet.clear()
        path = self.xlsx.text().strip()
        if not os.path.isfile(path):
            return
        from qgis.core import QgsProviderRegistry
        # OGR exposes each Excel worksheet as a sublayer.
        try:
            layer = QgsVectorLayer(path, 'Libro', 'ogr')
            if layer.isValid():
                sublayers = layer.dataProvider().subLayers()
                for entry in sublayers:
                    parts = entry.split('!!::!!')
                    if len(parts) > 1:
                        self.sheet.addItem(parts[1], parts[1])
                if not self.sheet.count():
                    self.sheet.addItem('Primera hoja', '')
        except Exception:
            pass
        self.load_columns()

    def source_excel(self):
        path = self.xlsx.text().strip()
        if not os.path.isfile(path):
            raise ValueError('Selecciona un Excel existente.')
        sheet = self.sheet.currentData()
        uri = path + ('|layername=' + sheet if sheet else '')
        layer = QgsVectorLayer(uri, 'Datos Excel', 'ogr')
        if not layer.isValid():
            raise ValueError('No se pudo abrir el Excel con OGR. Verifica el formato y que QGIS admita XLSX/XLS.')
        return layer

    def load_columns(self):
        for cb in (self.xcol, self.ycol, self.order):
            cb.clear()
        try:
            fields = [f.name() for f in self.source_excel().fields()]
        except Exception:
            return
        self.order.addItem('(orden original de filas)', '')
        for cb in (self.xcol, self.ycol, self.order):
            for name in fields:
                cb.addItem(name, name)
        for cb, candidates in ((self.xcol, ('X','ESTE','EASTING','LONGITUD','LON')),
                               (self.ycol, ('Y','NORTE','NORTHING','LATITUD','LAT')),
                               (self.order, ('ORDEN','ORDER','SECUENCIA'))):
            for candidate in candidates:
                match = next((i for i,f in enumerate(fields) if f.strip().upper()==candidate), None)
                if match is not None:
                    cb.setCurrentIndex(match + (1 if cb is self.order else 0))
                    break

    def write_memory(self, layer, path):
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = 'GPKG'
        options.fileEncoding = 'UTF-8'
        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer, path, QgsProject.instance().transformContext(), options)
        if result[0] != QgsVectorFileWriter.NoError:
            raise RuntimeError('Error al guardar GeoPackage: {}'.format(result[1]))
        self.load_result(path)

    def load_result(self, path, announce=True):
        layer = QgsVectorLayer(path, os.path.splitext(os.path.basename(path))[0], 'ogr')
        if layer.isValid():
            QgsProject.instance().addMapLayer(layer)
            self.iface.setActiveLayer(layer)
        self.status.setText('Creado: ' + path)
        if announce:
            QMessageBox.information(self, 'GeoTools GT', 'Proceso finalizado.\n' + path)
        self.refresh_layers()

    def guard(self, operation):
        try:
            operation()
        except Exception as exc:
            self.status.setText('Error: ' + str(exc))
            QMessageBox.critical(self, 'GeoTools GT | Error', str(exc))

    def run_excel(self):
        self.guard(self._run_excel)

    def coordinate_fields(self, names):
        # Asegurar nombres únicos incluso si el Excel ya contiene campos similares.
        results = []
        occupied = set(n.lower() for n in names)
        for base in ('X_COORD', 'Y_COORD', 'LON_WGS84', 'LAT_WGS84'):
            name = base
            suffix = 2
            while name.lower() in occupied:
                name = '{}_{}'.format(base, suffix)
                suffix += 1
            occupied.add(name.lower())
            results.append(QgsField(name, QVariant.Double))
        return results

    def coords_of(self, point, transform):
        geographic = transform.transform(point)
        return [point.x(), point.y(), geographic.x(), geographic.y()]

    def _run_excel(self):
        source = self.source_excel()
        xfield, yfield = self.xcol.currentData(), self.ycol.currentData()
        if not xfield or not yfield or xfield == yfield:
            raise ValueError('Selecciona columnas X e Y diferentes.')
        crs = self.get_crs(self.crs_excel)
        basepath = self.get_output(self.out_excel)
        stem = basepath[:-5]
        points_path, polygon_path = stem + '_puntos.gpkg', stem + '_poligono.gpkg'
        for outpath in (points_path, polygon_path):
            if os.path.exists(outpath):
                raise ValueError('Ya existe {}. Cambia el nombre base para evitar sobrescribir.'.format(outpath))
        transform = QgsCoordinateTransform(crs, QgsCoordinateReferenceSystem('EPSG:4326'), QgsProject.instance())
        pointlayer = QgsVectorLayer('Point?crs=' + crs.authid(), 'Puntos', 'memory')
        pt_provider = pointlayer.dataProvider()
        pt_provider.addAttributes(list(source.fields()) + self.coordinate_fields([f.name() for f in source.fields()]))
        pointlayer.updateFields()
        values, skipped = [], 0
        orderfield = self.order.currentData()
        for index, row in enumerate(source.getFeatures()):
            try:
                x = float(str(row[xfield]).replace(',', '.'))
                y = float(str(row[yfield]).replace(',', '.'))
                if not (math.isfinite(x) and math.isfinite(y)):
                    raise ValueError('Coordenada no finita')
                point = QgsPointXY(x, y)
                geo_attrs = self.coords_of(point, transform)
                ordering = row[orderfield] if orderfield else index
                values.append((ordering, point, row.attributes(), geo_attrs, index))
            except (ValueError, TypeError):
                skipped += 1
        if len(set((r[1].x(), r[1].y()) for r in values)) < 3:
            raise ValueError('Se requieren al menos tres coordenadas distintas para el polígono.')
        if orderfield:
            try:
                values.sort(key=lambda v: (float(v[0]), v[4]))
            except (ValueError, TypeError):
                values.sort(key=lambda v: (str(v[0]), v[4]))
        pt_features = []
        for _, point, attrs, coord_attrs, _ in values:
            feat = QgsFeature(pointlayer.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(point))
            feat.setAttributes(attrs + coord_attrs)
            pt_features.append(feat)
        pt_provider.addFeatures(pt_features)
        pointlayer.updateExtents()
        ordered_points = [r[1] for r in values]
        if ordered_points[0] != ordered_points[-1]:
            ordered_points.append(ordered_points[0])
        polygon_geom = QgsGeometry.fromPolygonXY([ordered_points])
        if polygon_geom.isEmpty() or not polygon_geom.isGeosValid():
            raise ValueError('El polígono es inválido o los vértices se cruzan. Verifica la columna ORDEN.')
        polygonlayer = QgsVectorLayer('Polygon?crs=' + crs.authid(), 'Poligono', 'memory')
        pg_provider = polygonlayer.dataProvider()
        pg_provider.addAttributes([QgsField('N_VERTICES', QVariant.Int),
                                   QgsField('AREA_HA', QVariant.Double),
                                   QgsField('PERIM_M', QVariant.Double)])
        polygonlayer.updateFields()
        measure = QgsDistanceArea()
        measure.setSourceCrs(crs, QgsProject.instance().transformContext())
        measure.setEllipsoid('WGS84')
        polygon_feature = QgsFeature(polygonlayer.fields())
        polygon_feature.setGeometry(polygon_geom)
        polygon_feature.setAttributes([len(ordered_points)-1,
                                       measure.measureArea(polygon_geom) / 10000.0,
                                       measure.measurePerimeter(polygon_geom)])
        pg_provider.addFeatures([polygon_feature])
        polygonlayer.updateExtents()
        self.save_memory_silent(pointlayer, points_path)
        self.save_memory_silent(polygonlayer, polygon_path)
        self.load_result(points_path, announce=False)
        self.load_result(polygon_path, announce=False)
        self.status.setText('Generados: {} y {}'.format(points_path, polygon_path))
        QMessageBox.information(self, 'GeoTools GT',
            'Se crearon puntos y polígono.\n\nPuntos: {}\nPolígono: {}\n\nFilas omitidas: {}'.format(
                points_path, polygon_path, skipped))

    def save_memory_silent(self, layer, path):
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = 'GPKG'
        options.fileEncoding = 'UTF-8'
        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer, path, QgsProject.instance().transformContext(), options)
        if result[0] != QgsVectorFileWriter.NoError:
            raise RuntimeError('Error al guardar {}: {}'.format(path, result[1]))

    def run_extract(self):
        self.guard(self._run_extract)

    def _run_extract(self):
        polygon = self.get_layer(self.polygons)
        path = self.get_output(self.out_extract)
        if not polygon.crs().isValid():
            raise ValueError('El polígono debe tener un SRC válido para calcular coordenadas.')
        intermediate = processing.run('native:extractvertices', {
            'INPUT': polygon, 'OUTPUT': 'memory:'}, feedback=QgsProcessingFeedback())['OUTPUT']
        transform = QgsCoordinateTransform(
            polygon.crs(), QgsCoordinateReferenceSystem('EPSG:4326'), QgsProject.instance())
        # Generar una capa nueva sin el campo fid heredado. Al exportar a
        # GeoPackage, OGR asignara una llave primaria unica a cada vertice.
        source_fields = intermediate.fields()
        retained_indices = [i for i, field in enumerate(source_fields)
                            if field.name().lower() != 'fid']
        retained_fields = [source_fields[i] for i in retained_indices]
        names = [field.name() for field in retained_fields]
        newfields = self.coordinate_fields(names)
        points = QgsVectorLayer('Point?crs=' + polygon.crs().authid(),
                                'Vertices con coordenadas', 'memory')
        provider = points.dataProvider()
        if not provider.addAttributes(retained_fields + newfields):
            raise RuntimeError('No fue posible crear los campos de salida.')
        points.updateFields()
        batch = []
        for feat in intermediate.getFeatures():
            pt = feat.geometry().asPoint()
            coords = self.coords_of(QgsPointXY(pt), transform)
            output_feat = QgsFeature(points.fields())
            output_feat.setGeometry(feat.geometry())
            output_feat.setAttributes([feat.attributes()[i] for i in retained_indices] + coords)
            batch.append(output_feat)
        if not batch:
            raise ValueError('La capa de poligonos no contiene vertices para extraer.')
        ok, _ = provider.addFeatures(batch)
        if not ok:
            raise RuntimeError('No se pudieron incorporar todos los vertices a la salida.')
        points.updateExtents()
        self.save_memory_silent(points, path)
        self.load_result(path)

    def run_reproject(self):
        self.guard(self._run_reproject)

    def _run_reproject(self):
        layer = self.get_layer(self.vector)
        if not layer.crs().isValid():
            raise ValueError('La capa no tiene un SRC válido. Primero verifica y define su SRC real.')
        crs = self.get_crs(self.target_crs)
        path = self.get_output(self.out_reproj)
        result = processing.run('native:reprojectlayer', {
            'INPUT': layer, 'TARGET_CRS': crs, 'OUTPUT': path},
            feedback=QgsProcessingFeedback())
        self.load_result(result['OUTPUT'])


class GeoToolsPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        self.action = QAction('GeoTools GT | Caja de geoprocesos', self.iface.mainWindow())
        self.action.triggered.connect(self.open_dialog)
        self.iface.addPluginToMenu('GeoTools GT', self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu('GeoTools GT', self.action)
            self.iface.removeToolBarIcon(self.action)

    def open_dialog(self):
        self.dialog = GeoToolsDialog(self.iface)
        self.dialog.exec_()
