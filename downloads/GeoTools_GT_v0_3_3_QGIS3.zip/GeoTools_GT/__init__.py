def classFactory(iface):
    from .geotools import GeoToolsPlugin
    return GeoToolsPlugin(iface)
